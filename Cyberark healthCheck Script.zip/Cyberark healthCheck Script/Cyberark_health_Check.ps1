﻿#***************************************************************************************************************************
#Cyberark Health Check Automation Effort
#Author: Hemant Chandani
#Version: 1.0 (Draft)
#Team Name: _VOIS - Offshore (Vodafone)
#***************************************************************************************************************************

Process {
<#
The Process Block is called after the BEGIN Block.
This will enable the majority of the script logic to be placed in the
top of the file. Any helper functions would be placed in the bottem
or Begin Part of the file. This makes the file easier to read.
-#>

#*************************************************************************************************************************
#Get all input file from the config file	
#*************************************************************************************************************************

$scriptDirectory = split-path -parent $MyInvocation.MyCommand.Definition
$scriptDirectory = $scriptDirectory + "\"
$workingLocation = $scriptDirectory + "Working\"
$fileDateTime = Get-Date -format "MMddyyyy_hhmmss"
$serverlist = Get-PropFileValue "SERVERLIST" $scriptDirectory
$serverArray = $serverlist -Split ","
$ConectionTestCount = Get-PropFileValue "CONNECTIONTESTCOUNT" $scriptDirectory
$SERVICETOCHECKArray = Get-PropFileValue "SERVICETOCHECK" $scriptDirectory "Array"
$SERVICETOCHECKArray = [System.Collections.ArrayList]$SERVICETOCHECKArray
$outputLocation = Get-PropFileValue "OUTPUTLOCATION" $scriptDirectory
$EmailDNS = Get-PropFileValue "Email_DNS" $scriptDirectory
$Email_Notification = Get-PropFileValue "Email_NOTIFICATION" $scriptDirectory
$Email_Notification = $Email_Notification.Split(",")
$Email_From = Get-PropFileValue "Email_FROM" $scriptDirectory
$DiskSpaceThreshold = Get-PropFileValue "DISKSPACETHRESHOLD" $scriptDirectory
$wasInclusionList = Get-PropFileValue "WASINCLUSIONLIST" $scriptDirectory
$W3SVCInclusionList = Get-PropFileValue "W3SVINCLUSIONLIST" $scriptDirectory
$tssdisInclusionList = Get-PropFileValue "TSSDISINCLUSIONLIST" $scriptDirectory
$termsericeInclusionList = Get-PropFileValue "TERMSERVICEINCLUSIONLIST" $scriptDirectory
$servicesExclusionArray = Get-PropFileValue "EXCLUSIONLIST" $scriptDirectory

#*************************************************************************************************************************
#Declare the Global Variable	
#*************************************************************************************************************************
$diskfinal = $NUll
$servicesList = ""
$outputObject = $Null
$global:Errors = 0
$global:DiskSpaceErrorCount = 0
$global:ServiceStateErrorCount = 0

#*************************************************************************************************************************
#Log File Creation	
#*************************************************************************************************************************

$fileDateTime = Get-Date -format "MMddyyyy_HHmmss"
$LogFileLocation = $scriptDirectory + "logs\cyberArkHealthCheckService_$fileDateTime.txt"
Set-Content -Path $Path $LogFileLocation -Value $logFile
$A = Get-Date; Add-Content -Path $logFileLocation -value "cyberArkHealthCheckService - Start. $A"


#*************************************************************************************************************************
#Clear working location	
#*************************************************************************************************************************
Clear-FolderContents $workingLocation


#*************************************************************************************************************************
#Clear working location	
#*************************************************************************************************************************
if ($global:Errors -eq 0) {
    $tempFile = $workingLocation + "TMPFile.txt"
    Set-Content -Path $tempFile -Value "Hostmname,CPU Utilization, Memory Utilization,All Drive Usage, Cyberark Service"
    }


#*************************************************************************************************************************
# Start of main loop	
#*************************************************************************************************************************
if ($global:Errors -eq 0) {
    $A = get-Date; Add-Content -Path $logFileLocation -Value "Start of main process -$A"
    ForEach ($server in $serverArray) {

    #Reset Disk Space Usuage and Services List and Other Flags on Every run	
    $diskfinal = $NULL
    $servicesList = ""
    $ConnectionsuccesfulFlag = $False

    #Test Connection on Each Server
    $A = get-Date; Add-Content -Path $logFileLocation -Value "Testing Connectivity of Server : $server, trying for $ConnectionTestCount time(s) - $A"
        Try{

            #$Test
            $servicePingDetails = Test-Connection -ComputerName $server -Count $ConectionTestCount -ErrorAction Stop
            $ConnectionsuccesfulFlag = $True
        }
        catch {exception}
        {
            $ConnectionsuccesfulFlag = $False
        }

    if($ConnectionsuccesfulFlag) {

    $cpu = Get-WmiObject -ComputerName $server win32_processor | Measure-Object -Property LoadPercentage -Average | Select Average
    $cpuAverage = $cpu.Average
    $ram = Get-WmiObject -ComputerName $server -Query "SELECT FreePhysicalMemory, TotalVisibleMemorySize FROM Win32_OperatingSystem"| Select freePhysical

    $ramAverage = [int] ((($ram.TotalVisibleMemorySize - $ram.FreePhysicalMemory) / $ram.TotalVisibleMemorySize)*100)

    $attachedLogicalDisks = Get-WmiObject Win32_LogicalDisk -ComputerName $server -Filter "DriveType = 3"

    #Disk Size Check
    ForEach ($disk in $attachedLogicalDisks) {

        $disklabel = $disk.DeviceID
        $usedspace = [int] (((($disk.Size - $disk.FreeSpace)/($disk.Size))*100))

        #Check drive space usage percentage
        Check-DriveUsageThreshold $server $diskLabel $usedspace

        if ($diskfinal -ne $Null) {
            $diskfinal = "$diskfinal;Drive $diskLabel $usedspace%"
        }
        Else {
            $$diskfinal = "$Drive $diskLabel $usedspace%"
        }

    } # END Disk size check

    #Check Server is in WAS Service inclusion List

    if ($wasInclusionList -match $server) {
        if ($SERVICESTOCHECKArray.contains("WAS")){}Else{flag = $SERVICESTOCHECKArray.Add("WAS")}
    }
    Else {
        if($SERVICESTOCHECKArray.contains("WAS")){flag = $SERVICESTOCHECKArray.Remove("WAS")}Else{}
    }
    #Check Server is in W3SVC Service inclusion List

    if ($W3SVCInclusionList -match $server) {
        if ($SERVICESTOCHECKArray.contains("W3SVC")){}Else{flag = $SERVICESTOCHECKArray.Add("W3SVC")}
    }
    Else {
        if($SERVICESTOCHECKArray.contains("W3SVC")){flag = $SERVICESTOCHECKArray.Remove("W3SVC")}Else{}
    }
    
    #Check Server is in tssdis Service inclusion List

      if ($tssdisInclusionList -match $server) {
        if ($SERVICESTOCHECKArray.contains("tssdis")){}Else{flag = $SERVICESTOCHECKArray.Add("tssdis")}
    }
    Else {
        if($SERVICESTOCHECKArray.contains("tssdis")){flag = $SERVICESTOCHECKArray.Remove("tssdis")}Else{}
    }

    #Check Server is in termservice Service inclusion List

      if ($termserviceInclusionList -match $server) {
        if ($SERVICESTOCHECKArray.contains("termservice")){}Else{flag = $SERVICESTOCHECKArray.Add("termservice")}
    }
    Else {
        if($SERVICESTOCHECKArray.contains("termservice")){flag = $SERVICESTOCHECKArray.Remove("termservice")}Else{}
    }


    ForEach ($servicesToCheck in $SERVICESTOCHECKArray) {

        #Write-Host "Checking the presence of service $servicesToCheck in $server"
        $servicedetails = Get-Service -ComputerName $server -Name "$servicesToCheck*" | select Displayname, Status

        if ($servicedetails -ne $NULL ){
            if ($servicedetails -is [Array]) {
                ForEach ($servicedetail in $servicedetails) {
                    $DisplayName = $servicedetail.DisplayName
                    $Status = $servicedetail.Status
                    #Check the current service
                    $Flag = Check-ServicesInexclusionList $server $DisplayName

                    if ($Flag) {}Else(Check-ServiceState $server $DisplayName $Status)

                    if( $servicesList -ne "") {
                        $servicesList = "$servicesList; DisplayName : $DisplayName Status : $Status"
                    }
                    Else{
                    $servicesList = "DisplayName : $DisplayName Status : $Status"
                    }
                }
            }
            Else{
                    
                    $DisplayName = $servicedetail.DisplayName
                    $Status = $servicedetail.Status

                    $Flag = Check-ServicesInexclusionList $server $DisplayName
                    #Write-Host " $server : $DisplayName $Status, in exclusion list : $Flag"
                    if ($Flag) {}Else{
                            Check-ServiceState $server $DisplayName $Status
                        }
                    if( $servicesList -ne "") {
                        $servicesList = "$servicesList; DisplayName : $DisplayName Status : $Status"
                    }
                    Else{
                    $servicesList = "DisplayName : $DisplayName Status : $Status"
                    }
                }
            }
        } # END Services Check

            $outputObject = "$server,$cpuAverage,$ramAverage,$diskfinal,$servicesList"
            #Write-Host $outputObject
            Add-Content -Path $rempFile -Value "$outputObject"
        }
        Else{

        #Not able to connect to server, send Notification
        $A = Get-Date; Add-Content -Path $logFileLocation -Value "Could Not Connect to Server : $server, sending alert"

        }

    } # END Looping through all Servers

}



#*************************************************************************************************************************
#Parse health Check report	
#*************************************************************************************************************************
if ($global:Errors -eq 0) {
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "End of main process - $A"
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "parsing healthcheck report - $A"
    $hlthChkprt = Rename-FileFormat -workingLocation $workingLocation -fileToBeRenamed $tempFile -FormatToBeReplaced ".txt" - -FormatToBeReplacedWith ".csv"
    $CyberArkReportName = Split-Path $hlthChkprt -leaf
}


#*************************************************************************************************************************
#Copy and Send Report to PUAM Team	
#*************************************************************************************************************************
if ($global:Errors -eq 0) {
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "Copying HealthCheckReport to Output Folder - Start $A"
    copy-files $hlthChkprt $outputLocation
}

if ($global:Errors -eq 0) {
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "CyberArkhealthCheckService - END. $A"
    if ($global.DiskSpaceErrorCount -gt 0 -AND $global:ServiceStateErrorCount -gt 0){
        $subject = "Cyber ark health report - issues found "
        $body = "PUAM Team, Pelase Check the Specific DiskSpace Issue and Service State Alerts"
        Send-EmailNotification $Email_From $Email_Notification $subject $EMailDNS "High" $body ""
    }
    Else{
    $subject = "Cyber ark health report - Zero issues found "
    $body = "Health Check report Script complete. no issues found. Status : green"
    Send-EmailNotification $Email_From $Email_Notification $subject $EMailDNS "High" $body "outputLocation\$CyberArkReportName"
    }

}

} #END Process Block

Begin{
<#
The BEGIN block is processed when the script is first loaded.
This is where any functions used in the script should be placed.
Once after this section is executed, the PROCESS block will be called.
#>


Function Get-PropFileValue($param, $searchDirectory, $paramType) {
    <#
    .DESCRIPTION
    Returns a single value or an array of values from a properties file.

    .EXAMPLE
    Get-PropFileValue <Property to return> <Directory of properties file>
        <type of return>

    .NOTES
    This Function will search a properties file for a specific line
    that starts with the wanted property. Once that line is found
    it will return the value from that line. If the paramType is 'array'
    the function will return an array that all start with the
    same Property name.
    #>

if( $paramType -eq "array") {
    $returnValue = @()
    } else {
        $return = ""
    }

    $param = $param + "="
    $fileAndPath = ($searchDirectory + "properties\config.ini")
    $file = New-Object System.IO.StreamReader -Arg $fileAndPath
    while ( $line = $file.ReadLine() ) {
        if( $line -like "$param" ) {
            if( $paramType -eq "array" ) {
                $returnValue = $returnValue + $line.Replace($param, "")
            } else {
                $returnValue = $line.replace($Param, "")
            }
        }
    }
    $file.Close()
    return $returnValue
} # END Get-PropFileValue

Function Send-EmailNotification($emailFrom, $emailTo, $emailSubject, $EMAIL_DNS, $mailPriority, $emailBody, $emailAttach) {
    <#
    .DESCRIPTION
    Generic function to send an email Notification when called.

    .EXAMPLE
    Send-EmailNotification <Email From> <Email To> <Email Carbon Copy> <Email Subject>
        <Email Body> <Email Attachment>
    #>
    #$Body = $emailBody | convertto-html
    if($emailAttach -ne "") {
        Send-MailMessage -to $emailTo -Subject $emailSubject -From $emailFrom -SmtpServer $EMAIL_DNS -BodyAsHTML $emailBody -Priority #$mailPriority -Attachments)
    } else {
        Send-MailMessage -to $emailTo -Subject $emailSubject -From $emailFrom -SmtpServer $EMAIL_DNS -BodyAsHTML $emailBody -Priority
    }
} #END Send-EmailNotification

Function Rename-FileFormat($workingLocation,$fileToBeRenamed,$FormatToBeReplaced,$FormatToBeReplacedWith,$outputFileName) {
<#.DESCRIPTION
Generic function to rename a file to the desired format specified.
name of the new file will contain the data and time it was converted.
#>
$fileFullpath = $fileToBeRenamed
$FileName = Spilt-Path $fileFullpath -leaf
$fileDate = Get-Date -format "MMddyyyy_HHmmss"
$nameOfNewFile = "$OutputFileName$fileDate$FormatToBeReplacedWith"
try{
    Rename-Item -Path $fileFullpath -NewName $nameOfNewFile
    }catch [system.exception] {
        $ErrorMessage = $error[0].ToString() + $error[0].InvocationInfo.PositionMessage
        $errorType = $error.Gettype()
        $A = Get-Date; Add-Content -Path $logFileLocation -Value "Unable to rename to the correct format. $A"
        Add-Content -Path $logFileLocation -Value $ErrorMessage
        Add-Content -Path $logFileLocation -Value $errorType
        $global:Errors = $global:Errors + 1
    }

    return ($workingLocation + "\" + $nameOfNewFile)
} #End Rename-FileFormat

Function Clear-FolderContents($Location){
    <#
    .DESCRIPTION
    Generic function to clear all the contents inside a folder

    #>
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "Attempting to Delete all the files in Location: $Location $A"
        $workingFolderItems = $Location + "*.*"
        try {
            Remove-Item $WorkingFolderItems | Where { ! $_.PSIsContainer }
            } catch [Exception] {
            $A = Get-Date; Add-Content -Path $logFileLocation -Value "Unable to Empty the $Location folder. Unable to remove file. $A"
            $errorDescription = $error[0].ToString() + $error[0].InvocationInfo.PositionMessage
            $errorType = $error.Gettype()
            Add-Content -Path $logFileLocation -Value $errorDescription
            Add-Content -Path $logFileLocation -Value $errorType
            $global:Errors = $global:Errors + 1
            }
    } #END Clear-FolderContents

Functions copy-files($Source,$destination) {
    <#
    .DESCRIPTION
        Generic function to copy files to destination folder

    #>
    try {
        Copy-Item -Path $Source -destination $destination
    }
    catch [system.exception]
    {
        $A = Get-Date; Add-Content -Path $logFileLocation -Value "Error : Unable to Copy File : $Source End of Script $A"
        $global:Errors = $global:Errors + 1
    } 
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "File Copy Complete : $Source to Destination : $destination - $A"
} #End Copy-files

Functionn Check-DriveUsageThreshold($servername,$driveName,$usedSpacePercentage) {
    <#
    .DESCRIPTION
    Custom function to Check a Drive Space has exceeded a threshold value.

    .NOTES
    Threshold value must be globally declared with the name DisckSpaceThreshold. Threshold is a percentage
    #>
    if($usedSpacePercentage -ge $DiskSpaceThreshold) {
    if($driveName -ne "P:") {
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "Drive Space issue detected in Server : $servername, sending alert - $A"
    $subject = "Drive space issue detected on server : $servername "
$emailBody=@"
PUAM Team, 

Please check and restore the Drive Space below the threshold percentage : $DiskSpaceThreshold.
Server = $servername,
Drive Name = $drivename,
Drive Space Usage = $usedSpacePercentage.
"@
    $global:DiskSpaceErrorCount = $global:DiskSpaceErrorCount + 1
    Send-EmailNotification -emailFrom $Email_From -emailTo $Email_Notification -emailSubject $subject -EMAIL_DNS $EMAILDNS -mailPriority "High" -emailBody
    }
    }

} #END Check-DriveUsageThresHold

Functionn Check-SerivesInexclusionList($server,$DisplayName) {
    <#
    .DESCRIPTION
    Custom function to Check Exclusion. Function returns true if in exclusion list.
    #>
    $flag =$false
    ForEach ($Exclusion in $servicesExclusionArray) {
        if ($Exclusion -match ($server + ':' + $DisplayName)) {
        $Flag = $True
        }
        Else{
        }
    }
    return $Flag
} #END Check-ServicesInexclusionList
    
    if($servicesStatus -eq "Stopped") {
    
    $A = Get-Date; Add-Content -Path $logFileLocation -Value "Critical Services is not active in Server : $server, sending alert to PUAM Team -$A"
    $subject = "Critical Services is not active in Server $server "
$emailBody=@"
PUAM Team, 

Please check and restore the below listed Cyberark Services
Server : $server,
Service Name : $serviceName,
ServiceStatus : $serviceStatus
"@
    $global:DiskSpaceErrorCount = $global:DiskSpaceErrorCount + 1
    Send-EmailNotification  $Email_From $Email_Notification $subject $EMAILDNS "High" $body ""
}
Else{
    #Service is Okay, No Action is Required
}
}

}







 










#Line no 89,105,208,232,261,319,406,448



















