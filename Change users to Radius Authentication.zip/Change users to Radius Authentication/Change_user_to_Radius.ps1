$list = ".\Users.txt"
$lines = Get-Content $list

Foreach($line in $lines)
{
	$A = "`"$($line.trim())`""
	Start-Process -Wait ".\Make_Radius.bat" $A
}
