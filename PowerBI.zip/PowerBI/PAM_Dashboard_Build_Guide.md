# CyberArk PAM Compliance & Coverage Dashboard – Build Kit

Source: `CyberArk_PAM_Compliance_Report_20260925_151423.xlsx` (sheet `CyberArk Compliance`, 143,748 rows, 14 columns)

---
## 1. What your data says (validate your dashboard against these numbers)

| KPI | Value |
|---|---|
| Total privileged accounts | **143,748** |
| Compliant | 15,636 (10.9%) |
| Non-Compliant | 11,106 (7.7%) |
| **Unknown (no rotation date recorded)** | **117,006 (81.4%)** |
| Compliance % of *assessed* accounts (Compliant / (Compliant+Non-Compliant)) | 58.5% |
| Managed / Non-Managed | 132,512 (92.2%) / 11,236 (7.8%) |
| Password retrieval = Yes / No | 50,022 / 93,726 |
| Tier-0 (T0) accounts / Non-T0 | 5,455 / 138,293 |
| Shared / Personal accounts | 140,109 / 3,639 |
| Avg password age – Compliant / Non-Compliant | 17 days / 726 days |
| Non-Compliant older than 1 year | ~8,300 |
| Safes / Platforms / Unique hosts | 3,923 / 477 / 26,503 |

**Headline story for management:** the real risk is not only the 11K non-compliant accounts, but the 117K "UNKNOWN" accounts (81%) – they have no rotation date, so CyberArk cannot prove they are rotated. Even Managed accounts are ~80% Unknown. T0 is the healthiest tier (61% compliant); Non-T0 is only 9%.

---
## 2. Load data – Power Query (Home > Transform data > Advanced Editor)

Replace the path with your file location.

```m
let
    Source   = Excel.Workbook(File.Contents("C:\Data\CyberArk_PAM_Compliance_Report_20260925_151423.xlsx"), null, true),
    Sheet    = Source{[Item="CyberArk Compliance", Kind="Sheet"]}[Data],
    Promoted = Table.PromoteHeaders(Sheet, [PromoteAllScalarTypes=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"Password Age Days", Int64.Type},
        {"Last Password Rotation Date", type datetime},
        {"Last Successful Reconciliation", type datetime}}),
    // Friendly compliance label
    Status = Table.AddColumn(Typed, "Compliance Group", each
        if [Compliance Status] = "COMPLIANT" then "Compliant"
        else if [Compliance Status] = "NON COMPLIANT" then "Non-Compliant"
        else "Unknown", type text),
    // Password age buckets
    AgeBucket = Table.AddColumn(Status, "Password Age Bucket", each
        if [Password Age Days] = null then "No rotation recorded"
        else if [Password Age Days] <= 30 then "0-30 days"
        else if [Password Age Days] <= 90 then "31-90 days"
        else if [Password Age Days] <= 180 then "91-180 days"
        else if [Password Age Days] <= 365 then "181-365 days"
        else if [Password Age Days] <= 730 then "1-2 years"
        else "2+ years", type text),
    AgeSort = Table.AddColumn(AgeBucket, "Age Bucket Sort", each
        if [Password Age Days] = null then 7
        else if [Password Age Days] <= 30 then 1
        else if [Password Age Days] <= 90 then 2
        else if [Password Age Days] <= 180 then 3
        else if [Password Age Days] <= 365 then 4
        else if [Password Age Days] <= 730 then 5 else 6, Int64.Type),
    // Region / site / technology parsed from Safe Name, e.g. GP-RAT-WIN-SYS-...
    Site = Table.AddColumn(AgeSort, "Site", each try Text.Split([Safe Name], "-"){1} otherwise null, type text),
    Tech = Table.AddColumn(Site, "Technology", each try Text.Split([Safe Name], "-"){2} otherwise null, type text),
    // Reconciliation flag
    Recon = Table.AddColumn(Tech, "Reconciliation Status", each
        if [Last Successful Reconciliation] = null then "Never reconciled" else "Reconciled", type text),
    Flag = Table.AddColumn(Recon, "Missing Platform", each if [Platform] = null then "Yes" else "No", type text)
in
    Flag
```
Name the query **PAM**. Then Modeling > Sort by column: `Password Age Bucket` by `Age Bucket Sort`.

---
## 3. DAX measures (Modeling > New measure; put them in a Display folder "KPIs")

```dax
Total Accounts      = COUNTROWS(PAM)
Compliant           = CALCULATE([Total Accounts], PAM[Compliance Group] = "Compliant")
Non Compliant       = CALCULATE([Total Accounts], PAM[Compliance Group] = "Non-Compliant")
Unknown             = CALCULATE([Total Accounts], PAM[Compliance Group] = "Unknown")

Compliant %         = DIVIDE([Compliant], [Total Accounts])
Non Compliant %     = DIVIDE([Non Compliant], [Total Accounts])
Unknown %           = DIVIDE([Unknown], [Total Accounts])
Assessed Compliance % = DIVIDE([Compliant], [Compliant] + [Non Compliant])

Managed Accounts    = CALCULATE([Total Accounts], PAM[Platform Management Type] = "MANAGED")
Non Managed Accounts= CALCULATE([Total Accounts], PAM[Platform Management Type] = "NON-MANAGED")
Managed Coverage %  = DIVIDE([Managed Accounts], [Total Accounts])

Retrieval Enabled   = CALCULATE([Total Accounts], PAM[Password Retrieval] = "Yes")
Retrieval Enabled % = DIVIDE([Retrieval Enabled], [Total Accounts])

T0 Accounts         = CALCULATE([Total Accounts], PAM[Asset Type] = "T0")
T0 Compliant %      = CALCULATE([Compliant %], PAM[Asset Type] = "T0")
Shared Accounts     = CALCULATE([Total Accounts], PAM[Account Type] = "Shared Account")
Personal Accounts   = CALCULATE([Total Accounts], PAM[Account Type] = "Personal Account")

Avg Password Age    = AVERAGE(PAM[Password Age Days])
Avg Age Non Compliant = CALCULATE([Avg Password Age], PAM[Compliance Group] = "Non-Compliant")
Older Than 1 Year   = CALCULATE([Total Accounts], PAM[Password Age Days] > 365)
Older Than 2 Years  = CALCULATE([Total Accounts], PAM[Password Age Days] > 730)
Never Reconciled    = CALCULATE([Total Accounts], PAM[Reconciliation Status] = "Never reconciled")
Never Reconciled %  = DIVIDE([Never Reconciled], [Total Accounts])

Distinct Safes      = DISTINCTCOUNT(PAM[Safe Name])
Distinct Platforms  = DISTINCTCOUNT(PAM[Platform])
Distinct Hosts      = DISTINCTCOUNT(PAM[Address])

// Risk score: Non-Compliant + Unknown on T0 assets (highest priority remediation)
T0 At Risk          = CALCULATE([Total Accounts], PAM[Asset Type] = "T0", PAM[Compliance Group] <> "Compliant")

// Conditional formatting helper (RAG)
Compliance RAG = SWITCH(TRUE(), [Compliant %] >= 0.9, "#2EA043", [Compliant %] >= 0.6, "#D29922", "#DA3633")
```

---
## 4. Report pages & visuals

Import `PAM_Theme.json` via View > Themes > Browse for themes. Use 16:9 canvas, white background, a dark navy top banner with the title.

### Page 1 – Executive Summary
- **KPI cards (top row):** Total Accounts · Compliant % · Non Compliant % · Unknown % · Managed Coverage % · T0 Compliant %. Use `Compliance RAG` for conditional font colour.
- **Donut:** Compliance Group (Compliant green / Non-Compliant red / Unknown grey).
- **100% stacked bar:** Compliance Group by Asset Type (T0 vs Non-T0).
- **Clustered column:** Password Age Bucket (sorted) – count of accounts.
- **Callout card:** Avg Age Non Compliant, Older Than 1 Year.
- **Slicers (left panel):** Safe Type, Asset Type, Account Type, Platform Management Type, Password Retrieval.

### Page 2 – Coverage
- Managed vs Non-Managed donut + Managed Coverage % gauge (target 100%).
- Password Retrieval Yes/No by Safe Type (stacked bar).
- Safe Type × Account Type matrix (rows = Safe Type, columns = Account Type, values = Total Accounts).
- Top 10 Platforms by account count (bar) with Compliant % as tooltip.
- Cards: Distinct Safes, Distinct Platforms, Distinct Hosts, Missing Platform.

### Page 3 – Compliance Deep-Dive
- Matrix: rows = Asset Type > Safe Type; columns = Compliance Group; values = counts with data bars.
- Stacked column: Compliance Group by Platform Management Type (shows Managed accounts are still 80% Unknown).
- Scatter/box-like: Password Age Days distribution by Compliance Group (histogram via Age Bucket).
- Treemap: Non-Compliant accounts by Technology.

### Page 4 – Password Age & Hygiene
- Age bucket column chart split by Asset Type.
- Cards: Older Than 1 Year, Older Than 2 Years, Avg Age Non Compliant, Never Reconciled %.
- Line chart: count of accounts by month of `Last Password Rotation Date` (rotation cadence trend).
- Column chart: Reconciliation Status by Platform Management Type.

### Page 5 – Remediation Worklist (drill-through target)
- Filter: Compliance Group ≠ Compliant. Table columns: Safe Name, Address, User Name, Platform, Asset Type, Password Age Days, Compliance Group, Last Successful Reconciliation.
- Top 10 Safes by Non-Compliant count (bar), Top 10 Platforms by Non-Compliant.
- Sort by Password Age Days descending. Enable Drill-through from other pages on Safe Name / Platform.

Top offenders today: platforms `RAT-ESX-SP-CM-VM-RM-30-API14` (1,084), `MIL-ESX-SP-CM-VM-RM-30-API14` (951), `RAT-UNX-SP-CM-VM-RM-P-CMSRecon-30` (946); safes `GP-RAT-ESX-SYS-DCOCNIVMW-UMP` (1,015), `GP-RAT-WIN-SYS-DCOCMPWIN-UMP` (843).

---
## 5. Extra things worth showcasing to management

1. **Unknown accounts (81%)** – the biggest coverage gap; add a target line and a "Unknown reduction" goal.
2. **T0 exposure** – 1,966 T0 accounts Unknown + 146 Non-Compliant (`T0 At Risk`).
3. **Trend over time** – this file is a single snapshot. Save each weekly export into a folder and use Get Data > Folder to append them, adding a `Report Date` column from the file name (…_20260925_…). This gives compliance trend lines, the most persuasive management visual.
4. **Non-Managed accounts (11,236)** – 100% unmanaged by CPM; candidates for onboarding.
5. **Reconciliation health** – 85% never reconciled.
6. **Shared vs Personal** – 97.5% shared accounts; personal accounts are 91% compliant.
7. **Data quality** – 303 blank Address, 38 blank Platform, 232 duplicate Object Names.
8. Optional extras if you can get more columns: Owner/Application, Region, Last Accessed date, Safe member count, dual-control/ticketing enabled, Session recording (PSM) coverage.

---
## 6. Publish tips
- Set the file refresh: Power BI Service > dataset > Scheduled refresh (needs gateway if the Excel is on a local drive; SharePoint/OneDrive avoids it).
- Save the file as **`.pbix`** in Desktop (File > Save As). Add a Bookmark for "Executive view" and use Page navigator buttons.
- Keep Page 1 to one screen with no scrolling; use Tooltip pages for detail.
