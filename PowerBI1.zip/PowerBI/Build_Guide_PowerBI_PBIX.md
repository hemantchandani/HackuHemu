# Building the Real .pbix — Step-by-Step Guide

This turns `PAM_PowerBI_DataModel.xlsx` into an actual Power BI Desktop file (`.pbix`), reproducing the executive dashboard with live, drillable visuals and working slicers. Takes ~10 minutes.

**Requires:** Power BI Desktop (free — Microsoft Store or powerbi.microsoft.com).

---

## 1. Import the data

1. Open Power BI Desktop → **Get Data → Excel Workbook**
2. Select `PAM_PowerBI_DataModel.xlsx`
3. Check the **PAM_Fact_Table**, click **Transform Data**
4. In Power Query, confirm data types: `Password Age (Days)` → Whole Number; all others → Text. Click **Close & Apply**.

## 2. Add the DAX measures

**Modeling tab → New Measure**, add each of these to the PAM_Fact_Table:

```dax
Total Accounts = COUNTROWS(PAM_Fact_Table)

Compliant Accounts = CALCULATE([Total Accounts], PAM_Fact_Table[Compliance Status] = "Compliant")

Non-Compliant Accounts = CALCULATE([Total Accounts], PAM_Fact_Table[Compliance Status] = "Non-Compliant")

Compliance Rate = DIVIDE([Compliant Accounts], [Total Accounts], 0)

Distinct Safes = DISTINCTCOUNT(PAM_Fact_Table[Safe Name])

Markets Covered = DISTINCTCOUNT(PAM_Fact_Table[Market Name])

Avg Password Age = AVERAGE(PAM_Fact_Table[Password Age (Days)])

Compliance Rate % (formatted) = FORMAT([Compliance Rate], "0.0%")
```

Optional — password age bucket for the histogram (**New Column**, not measure):

```dax
Age Bucket =
SWITCH(
    TRUE(),
    PAM_Fact_Table[Password Age (Days)] <= 30, "0-30",
    PAM_Fact_Table[Password Age (Days)] <= 60, "31-60",
    PAM_Fact_Table[Password Age (Days)] <= 90, "61-90",
    PAM_Fact_Table[Password Age (Days)] <= 180, "91-180",
    PAM_Fact_Table[Password Age (Days)] <= 365, "181-365",
    "365+"
)
```

## 3. Build the visuals (matches the HTML dashboard layout)

| Visual | Type | Fields |
|---|---|---|
| Total Accounts | Card | `[Total Accounts]` |
| Compliance Rate | Card | `[Compliance Rate]` (format as %) |
| Non-Compliant | Card | `[Non-Compliant Accounts]` |
| Distinct Safes | Card | `[Distinct Safes]` |
| Markets Covered | Card | `[Markets Covered]` |
| Avg Password Age | Card | `[Avg Password Age]` |
| Compliance by Market | Stacked bar | Axis: `Market Name`, Legend: `Compliance Status`, Value: `[Total Accounts]` |
| Overall Compliance | Donut | Legend: `Compliance Status`, Value: `[Total Accounts]` |
| Compliance by Safe Type | Stacked column | Axis: `Safe Type`, Legend: `Compliance Status`, Value: `[Total Accounts]` |
| Password Age Distribution | Column | Axis: `Age Bucket`, Value: `[Total Accounts]` |
| LDAP Status | Donut | Legend: `LDAP Status`, Value: `[Total Accounts]` |
| Account Detail | Table | Safe Name, Safe Type, Account Name, Market Name, Password Age (Days), Compliance Status, LDAP Status, Retrieve Option |

## 4. Add the filters (slicers)

Insert a **Slicer** visual for each of: `Safe Type`, `Market Name`, `Compliance Status`, `LDAP Status`, `Retrieve Option`. Set them to "Sync slicers" across all report pages if you split KPIs/charts/table into separate tabs.

## 5. Apply the look

- Report theme: **View → Themes → Customize current theme** → set accent color to `#E60000` (Vodafone red), background `#0B0F14`, add `#2FD1A3` (compliant/teal) and keep red for non-compliant.
- Format cards: dark card background, white/light-grey text, red top accent bar (Format pane → Effects → Background).

## 6. Publish

**File → Publish → Power BI Service** (needs a Power BI account/workspace) to share it as a live dashboard link, or just **File → Save** to keep the `.pbix` locally and email/share the file directly.

---

### Reference numbers (as of this data snapshot)
- Total accounts: **3,154**
- Compliant: **3,021 (95.8%)**
- Non-compliant: **133 (4.2%)**
- Distinct safes: **2,668**
- Markets covered: **22**
- Average password age: **~13 days** (max observed: 857 days)
