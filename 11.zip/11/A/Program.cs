using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Configuration;
using OfficeOpenXml;
using System.Drawing;
using CCPHelperLib;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace AWSReportingPowerBI
{
    public class tableMapping
    {
        public string Table { get; set; }
        public string mapTable { get; set; }
    }

    internal class Program
    {
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
                                int dwLogonType, int dwLogonProvider, out SafeAccessTokenHandle phToken);

        const int LOGON32_PROVIDER_DEFAULT = 0;
        const int LOGON32_LOGON_INTERACTIVE = 2;
        const int LOGON32_LOGON_SERVICE = 5;

        static int Main(string[] args)
        {
            try
            {
                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Executing Report Query");
                SqlConnection conn;

                string rawCCPServers = ReadApplicationSettings("CCPServers");
                if (rawCCPServers.Last() == ';') rawCCPServers = rawCCPServers.Remove(rawCCPServers.Length - 1, 1);
                List<string> ccpServers = rawCCPServers.Split(';').ToList();

                CCPCredential ccpCred = new CCPCredential();
                CCPHelper thisCCP = new CCPHelper();
                try
                {
                    ccpCred = thisCCP.CCPRetrievalRequest(ccpServers, ReadApplicationSettings("AppID"), ReadApplicationSettings("SafeName"), ReadApplicationSettings("ObjectName"));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                string sqlConnectionString = ConfigurationManager.ConnectionStrings["SQLReportingDB"].ToString();

                SafeAccessTokenHandle safeAccessTokenHandle;
                bool svcAcctLogon = LogonUser(
                    ccpCred.Username,
                    ccpCred.LogonDomain,
                    ccpCred.Password,
                    LOGON32_LOGON_SERVICE, LOGON32_PROVIDER_DEFAULT,
                    out safeAccessTokenHandle);

                if (!svcAcctLogon)
                {
                    Console.WriteLine($@"Generation of Impersonation Access Token for {ccpCred.LogonDomain}\{ccpCred.Username} failed");
                    Console.WriteLine($@"{ccpCred.LogonDomain}\{ccpCred.Username} is a SERVICE User and requires Logon As A Service Right");

                    int ret = Marshal.GetLastWin32Error();
                    Console.WriteLine($"LogonUser failed with error code: {ret}");
                    throw new System.ComponentModel.Win32Exception(ret);
                }

                Console.WriteLine($@"Generating Impersonation Access Token for {ccpCred.LogonDomain}\{ccpCred.Username} was successful");

                DataSet dsAWSAccounts = new DataSet("dsAWSAccounts");
                string outputFolder = string.Empty, outputFilename = string.Empty;
                string reportQuery = "spRPTGetAWSAccounts";
                int sqlTimeout = -1;

                #region Map .Net DataSet tables to WorkSheets (Tabs)
                List<tableMapping> worksheetTabs = new List<tableMapping> {
                     new tableMapping { Table = "Table", mapTable = "AWS Assets" },
                    
                };
                #endregion

                int.TryParse(ReadApplicationSettings("SQLQueryTimeout"), out sqlTimeout);

                #region Create Database connection & retrieve AWS Account Reporting Datasets
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, () =>
                {
                    using (conn = new SqlConnection(sqlConnectionString))
                    {
                        using (SqlCommand sqlComm = new SqlCommand(reportQuery, conn))
                        {
                            sqlComm.CommandTimeout = sqlTimeout;
                            sqlComm.CommandType = CommandType.StoredProcedure;
                            conn.Open();

                            SqlDataAdapter sa = new SqlDataAdapter(sqlComm);

                            foreach (tableMapping thisMap in worksheetTabs)
                            {
                                sa.TableMappings.Add(thisMap.Table, thisMap.mapTable);
                            }

                            sa.Fill(dsAWSAccounts);
                        }
                    }
                });
                #endregion

                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Completed Report Query");
                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Starting Workbook Creation");

                #region Creation Workbook in memory & style

                outputFolder = ConfigurationManager.AppSettings["ReportOutputFolder"].ToString();
                if (!outputFolder[outputFolder.Length - 1].Equals("\\")) outputFolder += "\\";

                string safeDate = DateTime.Now.ToString("dd.MM.yyyy");
                outputFilename = Path.Combine(outputFolder, $"AWS PAMCentral CyberArk {safeDate}.xlsx");
                
                if (dsAWSAccounts.Tables["AWS Assets"].Rows.Count == 0)
                {
                    Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Report Generation Failed - No data has been returned from the PAM Reporting Database");
                    SMTPOperations.SendEmail(outputFilename, true);
                    Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Report Email Sent to Teams Channel & Recipients");

                    dsAWSAccounts.Tables.Clear();
                    dsAWSAccounts.Clear();

                    return 1;
                }

                FileInfo thisFile = new FileInfo(outputFilename);

                if (thisFile.Exists)
                {
                    thisFile.Delete();  // ensures we create a new workbook
                    thisFile = new FileInfo(outputFilename);
                }

                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                ExcelPackage pck = new ExcelPackage(thisFile);
                ExcelRange titleRange;

                foreach (DataTable thisTable in dsAWSAccounts.Tables)
                {
                    ExcelWorksheet worksheet = pck.Workbook.Worksheets.Add(thisTable.TableName);

                    titleRange = worksheet.Cells["A1:" + PositionToColumn(thisTable.Columns.Count) + "1"];
                    titleRange.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    titleRange.Style.Fill.BackgroundColor.SetColor(Color.DarkSlateBlue);
                    titleRange.Style.Font.Color.SetColor(Color.White);

                    for (int i = 0; i < thisTable.Columns.Count; i++)
                    {
                        worksheet.Cells[PositionToColumn(i + 1) + "1"].Value = thisTable.Columns[i].ColumnName;
                        if (thisTable.Columns[i].DataType.FullName.Equals("System.DateTime")) worksheet.Column(i + 1).Style.Numberformat.Format = "yyyy-MM-dd hh:mm:ss";
                    }
                    titleRange.AutoFilter = true;


                    worksheet.Cells["A2"].LoadFromDataTable(thisTable, false);

                    worksheet.Cells[worksheet.Dimension.Address].Style.Font.SetFromFont("calibri", 9);

                    worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                    for (int i = 1; i < worksheet.Dimension.Columns + 1; i++)
                    {
                        worksheet.Column(i).Width += 3;
                    }

                }
                #endregion



                #region Write Workbook to file
                pck.Save();
                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Report Generation Complete");
                SMTPOperations.SendEmail(outputFilename);
                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Report Email Sent to Teams Channel");

                dsAWSAccounts.Tables.Clear();
                dsAWSAccounts.Clear();

                #endregion

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An Error has occurred - terminating");
                Console.WriteLine(ex.Data);
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.Source);
                Console.WriteLine(ex.InnerException);
            }

            return 1;
        }

        static public string ReadApplicationSettings(string AppKey)
        {
            return ConfigurationManager.AppSettings[AppKey].ToString();
        }

        static public int ColumnToPosition(char colName)
        {
            return (int)colName % 32;
        }

        public static string PositionToColumn(int colPosition)
        {
            string result = string.Empty;
            while (--colPosition >= 0)
            {
                result = (char)('A' + colPosition % 26) + result;
                colPosition /= 26;
            }
            return result;
        }
    }
}
