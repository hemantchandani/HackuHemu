using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Configuration;
using OfficeOpenXml;
using System.Drawing;
using OfficeOpenXml.Drawing.Chart;
using OfficeOpenXml.Style;
using CCPHelperLib;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace T0OnboardingStatus
{
    public class tableMapping
    {
        public string Table { get; set; }
        public string mapTable { get; set; }
    }

    internal class Program
    {
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
                                int dwLogonType, int dwLogonProvider, out SafeAccessTokenHandle phToken);

        const int LOGON32_PROVIDER_DEFAULT = 0;
        const int LOGON32_LOGON_INTERACTIVE = 2;
        const int LOGON32_LOGON_SERVICE = 5;

        static int Main(string[] args)
        {
            try
            {
                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Executing Report Query"); 
                SqlConnection conn;
                
                string rawCCPServers = ReadApplicationSettings("CCPServers");
                if (rawCCPServers.Last() == ';') rawCCPServers = rawCCPServers.Remove(rawCCPServers.Length - 1, 1);
                List<string> ccpServers = rawCCPServers.Split(';').ToList();

                CCPCredential ccpCred = new CCPCredential();
                CCPHelper thisCCP = new CCPHelper();
                try
                {
                    ccpCred = thisCCP.CCPRetrievalRequest(ccpServers, ReadApplicationSettings("AppID"), ReadApplicationSettings("SafeName"), ReadApplicationSettings("ObjectName"));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                string sqlConnectionString = ConfigurationManager.ConnectionStrings["SQLReportingDB"].ToString();

                SafeAccessTokenHandle safeAccessTokenHandle;
                bool svcAcctLogon = LogonUser(
                    ccpCred.Username,
                    ccpCred.LogonDomain,
                    ccpCred.Password,
                    LOGON32_LOGON_SERVICE, LOGON32_PROVIDER_DEFAULT,
                    out safeAccessTokenHandle);

                if (!svcAcctLogon)
                {
                    Console.WriteLine($@"Generation of Impersonation Access Token for {ccpCred.LogonDomain}\{ccpCred.Username} failed");
                    Console.WriteLine($@"{ccpCred.LogonDomain}\{ccpCred.Username} is a SERVICE User and requires Logon As A Service Right");

                    int ret = Marshal.GetLastWin32Error();
                    Console.WriteLine($"LogonUser failed with error code: {ret}");
                    throw new System.ComponentModel.Win32Exception(ret);
                }

                Console.WriteLine($@"Generating Impersonation Access Token for {ccpCred.LogonDomain}\{ccpCred.Username} was successful");

                DataSet dsT0OnboardingData = new DataSet("dsT0OnboardingData");
                string outputFolder = string.Empty, outputFilename = string.Empty;
                string reportQuery = "spRPT_T0Coverage";
                
                int sqlTimeout = -1;

                #region Map .Net DataSet tables to WorkSheets (Tabs)
                List<tableMapping> worksheetTabs = new List<tableMapping> {
                new tableMapping { Table = "Table", mapTable = "T0 Asset Details" },
                new tableMapping { Table = "Table1", mapTable = "T0 Asset CyberArk Details" },
                new tableMapping { Table = "Table2", mapTable = "T0 Onboarding Statistics" },
                new tableMapping { Table = "Table3", mapTable = "T0 Compliance Statistics" },
                new tableMapping { Table = "Table4", mapTable = "T0 ILO Asset Details" },
                new tableMapping { Table = "Table5", mapTable = "T0 ILO Asset CyberArk Details" },
                new tableMapping { Table = "Table6", mapTable = "T0 ILO Onboarding Statistics" },
                new tableMapping { Table = "Table7", mapTable = "T0 ILO Compliance Statistics" }};
                #endregion

                int.TryParse(ReadApplicationSettings("SQLQueryTimeout"), out sqlTimeout);

                #region Create Database connection & retrieve T0 Onboarding Reporting Datasets
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, () =>
                {
                    using (conn = new SqlConnection(sqlConnectionString))
                    {
                        using (SqlCommand sqlComm = new SqlCommand(reportQuery, conn))
                        {
                            sqlComm.CommandTimeout = sqlTimeout;
                            sqlComm.CommandType = CommandType.StoredProcedure;
                            conn.Open();

                            SqlDataAdapter sa = new SqlDataAdapter(sqlComm);

                            foreach (tableMapping thisMap in worksheetTabs)
                            {
                                sa.TableMappings.Add(thisMap.Table, thisMap.mapTable);
                            }

                            sa.Fill(dsT0OnboardingData);
                        }
                    }
                });

                #endregion

                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Completed Report Query");

                #region Creation Workbook in memory & style

                outputFolder = ConfigurationManager.AppSettings["ReportOutputFolder"].ToString();
                if (!outputFolder[outputFolder.Length - 1].Equals("\\")) outputFolder += "\\";

                string safeDate = DateTime.Now.ToString("dd.MM.yyyy");
                outputFilename = Path.Combine(outputFolder, $"CyberArk Reporting - T0 Onboarding {safeDate}.xlsx");

                FileInfo thisFile = new FileInfo(outputFilename);

                if (thisFile.Exists)
                {
                    thisFile.Delete();  // ensures we create a new workbook
                    thisFile = new FileInfo(outputFilename);
                }

                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                ExcelPackage pck = new ExcelPackage(thisFile);
                ExcelRange titleRange;

                foreach (DataTable thisTable in dsT0OnboardingData.Tables)
                {
                    ExcelWorksheet worksheet = pck.Workbook.Worksheets.Add(thisTable.TableName);

                    titleRange = worksheet.Cells["A1:" + PositionToColumn(thisTable.Columns.Count) + "1"];
                    titleRange.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    titleRange.Style.Fill.BackgroundColor.SetColor(Color.DarkSlateBlue);
                    titleRange.Style.Font.Color.SetColor(Color.White);

                    for (int i = 0; i < thisTable.Columns.Count; i++)
                    {
                        worksheet.Cells[PositionToColumn(i + 1) + "1"].Value = thisTable.Columns[i].ColumnName;
                        if (thisTable.Columns[i].DataType.FullName.Equals("System.DateTime")) worksheet.Column(i + 1).Style.Numberformat.Format = "yyyy-MM-dd hh:mm:ss";
                    }
                    titleRange.AutoFilter = true;


                    switch (thisTable.TableName.ToUpper())
                    {
                        case "T0 ONBOARDING STATISTICS":
                        case "T0 ILO ONBOARDING STATISTICS":

                            worksheet.Cells["H1"].Value = string.Format($"Report Date: {DateTime.Now.ToShortDateString()}");
                            worksheet.Cells["H1"].Style.Font.Bold = true;
                            worksheet.Column(6).Style.Numberformat.Format = "#0\\.00%";

                            worksheet.Cells["A2"].LoadFromDataTable(thisTable, false);
                            if (thisTable.Rows.Count > 0)
                            {
                                ExcelBarChart barChart = (ExcelBarChart)worksheet.Drawings.AddChart("T0 Asset Onboarding Statistics Col", eChartType.ColumnStacked1003D);
                                barChart.Style = eChartStyle.Style10;
                                worksheet.Cells[worksheet.Dimension.Address].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                                worksheet.Cells["A1:" + PositionToColumn(thisTable.Columns.Count) + "1"].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                                worksheet.Cells["A:A"].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;

                                barChart.SetPosition(8, 0, 1, 0);
                                barChart.SetSize(640, 480);
                                barChart.DataLabel.ShowSeriesName = true;
                                barChart.DataLabel.ShowPercent = true;
                                barChart.DataLabel.ShowValue = true;
                                barChart.Title.Text = string.Format($"T0 Asset Onboarding Statistics - {DateTime.Now.ToShortDateString()}");
                                barChart.XAxis.Title.Text = "Operating System Types";

                                ExcelPieChart pieChart = (ExcelPieChart)worksheet.Drawings.AddChart("T0 Asset Onboarding Statistics Pie", eChartType.PieExploded3D);
                                pieChart.Style = eChartStyle.Style10;
                                pieChart.SetPosition(8, 0, 12, 0);
                                pieChart.SetSize(640, 480);

                                switch (thisTable.TableName.ToUpper())
                                {
                                    case "T0 ONBOARDING STATISTICS":
                                    case "T0 ILO ONBOARDING STATISTICS":
                                        worksheet.Column(6).Style.Numberformat.Format = "#0\\.00%";

                                        ExcelChartSerie srvSeries1 = barChart.Series.Add("B2:B" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                        ExcelChartSerie srvSeries2 = barChart.Series.Add("C2:C" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                        ExcelChartSerie srvSeries3 = barChart.Series.Add("D2:D" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                        srvSeries1.HeaderAddress = new ExcelAddress("'T0 Onboarding Statistics'!B1");
                                        srvSeries2.HeaderAddress = new ExcelAddress("'T0 Onboarding Statistics'!C1");
                                        srvSeries3.HeaderAddress = new ExcelAddress("'T0 Onboarding Statistics'!D1");

                                        ExcelPieChartSerie srvPieSeries1 = pieChart.Series.Add("B" + (thisTable.Rows.Count + 2) + ":D" + (thisTable.Rows.Count + 2), "B1:D1");
                                        pieChart.DataLabel.ShowSeriesName = true;
                                        pieChart.DataLabel.ShowPercent = true;
                                        pieChart.DataLabel.ShowValue = true;
                                        
                                        worksheet.Cells["A" + (thisTable.Rows.Count + 2) + ":F" + (thisTable.Rows.Count + 2)].Style.Border.Top.Style = ExcelBorderStyle.Double;
                                        worksheet.Cells["A" + (thisTable.Rows.Count + 2)].Value = "Totals";
                                        worksheet.Cells["B" + (thisTable.Rows.Count + 2)].Formula = "=SUM(B2:B" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["C" + (thisTable.Rows.Count + 2)].Formula = "=SUM(C2:C" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["D" + (thisTable.Rows.Count + 2)].Formula = "=SUM(D2:D" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["E" + (thisTable.Rows.Count + 2)].Formula = "=SUM(E2:E" + (thisTable.Rows.Count + 1) + ")";
                                        //worksheet.Cells["F" + (thisTable.Rows.Count + 2)].Formula = "=AVERAGE(F2:F" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["F" + (thisTable.Rows.Count + 2)].Formula = "=B" + (thisTable.Rows.Count + 2) + "/(E" + (thisTable.Rows.Count + 2) + "-D" + (thisTable.Rows.Count + 2) + ") * 100";

                                        worksheet.Cells["E" + (thisTable.Rows.Count + 2)].Calculate();
                                        var srvTotalCell = worksheet.Cells["E" + (thisTable.Rows.Count + 2)].GetCellValue<string>();
                                        pieChart.Title.Text = string.Format($"T0 Asset Onboarding Totals ({srvTotalCell} Assets) - {DateTime.Now.ToShortDateString()}");

                                        break;

                                    case "T0 ILO ONBOARDING STATISTICSxxx":
                                        worksheet.Column(5).Style.Numberformat.Format = "#0\\.00%";

                                        ExcelChartSerie iloSeries1 = barChart.Series.Add("B2:B" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                        ExcelChartSerie iloSeries2 = barChart.Series.Add("C2:C" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                        iloSeries1.HeaderAddress = new ExcelAddress("'T0 Onboarding Statistics'!B1");
                                        iloSeries2.HeaderAddress = new ExcelAddress("'T0 Onboarding Statistics'!C1");

                                        ExcelPieChartSerie iloPieSeries1 = pieChart.Series.Add("B" + (thisTable.Rows.Count + 2) + ":C" + (thisTable.Rows.Count + 2), "B1:D1");
                                        pieChart.DataLabel.ShowSeriesName = true;
                                        pieChart.DataLabel.ShowPercent = true;
                                        pieChart.DataLabel.ShowValue = true;

                                        worksheet.Cells["A" + (thisTable.Rows.Count + 2) + ":F" + (thisTable.Rows.Count + 2)].Style.Border.Top.Style = ExcelBorderStyle.Double;
                                        worksheet.Cells["A" + (thisTable.Rows.Count + 2)].Value = "Totals";
                                        worksheet.Cells["B" + (thisTable.Rows.Count + 2)].Formula = "=SUM(B2:B" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["C" + (thisTable.Rows.Count + 2)].Formula = "=SUM(C2:C" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["D" + (thisTable.Rows.Count + 2)].Formula = "=SUM(D2:D" + (thisTable.Rows.Count + 1) + ")";
                                        //worksheet.Cells["E" + (thisTable.Rows.Count + 2)].Formula = "=AVERAGE(E2:E" + (thisTable.Rows.Count + 1) + ")";
                                        worksheet.Cells["F" + (thisTable.Rows.Count + 2)].Formula = "=B" + (thisTable.Rows.Count + 2) + "/(E" + (thisTable.Rows.Count + 2) + ") * 100";

                                        worksheet.Cells["E" + (thisTable.Rows.Count + 2)].Calculate();
                                        var iloTotalCell = worksheet.Cells["E" + (thisTable.Rows.Count + 2)].GetCellValue<string>();
                                        pieChart.Title.Text = string.Format($"T0 Asset Onboarding Totals ({iloTotalCell} Assets) - {DateTime.Now.ToShortDateString()}");

                                        break;
                                }                                                  
                           }
                            break;

                        case "T0 COMPLIANCE STATISTICS":
                        case "T0 ILO COMPLIANCE STATISTICS":

                            worksheet.Cells["H1"].Value = string.Format($"Report Date: {DateTime.Now.ToShortDateString()}");
                            worksheet.Cells["H1"].Style.Font.Bold = true;
                            worksheet.Column(6).Style.Numberformat.Format = "#0\\.00%";

                            worksheet.Cells["A2"].LoadFromDataTable(thisTable, false);
                            if (thisTable.Rows.Count > 0)
                            {
                                ExcelBarChart barChart = (ExcelBarChart)worksheet.Drawings.AddChart("T0 Asset Compliance Statistics Col", eChartType.ColumnStacked1003D);
                                barChart.Style = eChartStyle.Style10;
                                worksheet.Cells[worksheet.Dimension.Address].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                                worksheet.Cells["A1:" + PositionToColumn(thisTable.Columns.Count) + "1"].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                                worksheet.Cells["A:A"].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;

                                barChart.SetPosition(8, 0, 1, 0);
                                barChart.SetSize(640, 480);
                                ExcelChartSerie series1 = barChart.Series.Add("B2:B" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                ExcelChartSerie series2 = barChart.Series.Add("C2:C" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                ExcelChartSerie series3 = barChart.Series.Add("D2:D" + (thisTable.Rows.Count + 1), "A2:A" + (thisTable.Rows.Count + 1));
                                series1.HeaderAddress = new ExcelAddress("'T0 Compliance Statistics'!B1");
                                series2.HeaderAddress = new ExcelAddress("'T0 Compliance Statistics'!C1");
                                series3.HeaderAddress = new ExcelAddress("'T0 Compliance Statistics'!D1");

                                barChart.DataLabel.ShowSeriesName = true;
                                barChart.DataLabel.ShowPercent = true;
                                barChart.DataLabel.ShowValue = true;
                                barChart.Title.Text = string.Format($"T0 Onboarded Account Compliance Totals - {DateTime.Now.ToShortDateString()}");
                                barChart.XAxis.Title.Text = "Operating System Types";

                                worksheet.Cells["A" + (thisTable.Rows.Count + 2) + ":F" + (thisTable.Rows.Count + 2)].Style.Border.Top.Style = ExcelBorderStyle.Double;
                                worksheet.Cells["A" + (thisTable.Rows.Count + 2)].Value = "Totals";
                                worksheet.Cells["B" + (thisTable.Rows.Count + 2)].Formula = "=SUM(B2:B" + +(thisTable.Rows.Count + 1) + ")";
                                worksheet.Cells["C" + (thisTable.Rows.Count + 2)].Formula = "=SUM(C2:C" + +(thisTable.Rows.Count + 1) + ")";
                                worksheet.Cells["D" + (thisTable.Rows.Count + 2)].Formula = "=SUM(D2:D" + +(thisTable.Rows.Count + 1) + ")";
                                worksheet.Cells["E" + (thisTable.Rows.Count + 2)].Formula = "=SUM(E2:E" + +(thisTable.Rows.Count + 1) + ")";
                                //worksheet.Cells["F" + (thisTable.Rows.Count + 2)].Formula = "=AVERAGE(F2:F" + +(thisTable.Rows.Count + 1) + ")";
                                worksheet.Cells["F" + (thisTable.Rows.Count + 2)].Formula = "=B" + (thisTable.Rows.Count + 2) + "/(E" + (thisTable.Rows.Count + 2) + "-D" + (thisTable.Rows.Count + 2) + ") * 100";


                                worksheet.Cells["F" + (thisTable.Rows.Count + 2)].Calculate();
                                var totalCell = worksheet.Cells["E" + (thisTable.Rows.Count + 2)].GetCellValue<string>();

                                ExcelPieChart pieChart = (ExcelPieChart)worksheet.Drawings.AddChart("T0 Onboarded Account Compliance Statistics Pie", eChartType.PieExploded3D);
                                pieChart.Style = eChartStyle.Style10;
                                pieChart.SetPosition(8, 0, 12, 0);
                                pieChart.SetSize(640, 480);
                                ExcelPieChartSerie pieSeries1 = pieChart.Series.Add("B" + (thisTable.Rows.Count + 2) + ":E" + (thisTable.Rows.Count + 2), "B1:E1");
                                pieChart.DataLabel.ShowSeriesName = true;
                                pieChart.DataLabel.ShowPercent = true;
                                pieChart.DataLabel.ShowValue = true;
                                pieChart.Title.Text = string.Format($"T0 Onboarded Account Compliance Totals ({totalCell} Accounts) - {DateTime.Now.ToShortDateString()}");
                            }
                            break;

                        default:
                            worksheet.Cells["A2"].LoadFromDataTable(thisTable, false);
                            break;
                    }

                    worksheet.Cells[worksheet.Dimension.Address].Style.Font.SetFromFont("calibri", 9);
                    if (thisTable.TableName.ToUpper() == "T0 ONBOARDING STATISTICS" || thisTable.TableName.ToUpper() == "T0 COMPLIANCE STATISTICS"
                        || thisTable.TableName.ToUpper() == "T0 ILO ONBOARDING STATISTICS" || thisTable.TableName.ToUpper() == "T0 ILO COMPLIANCE STATISTICS")
                    {
                        worksheet.Cells["H1"].Style.Font.Size = 14;
                        worksheet.Cells["H1"].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                    }
                    worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                    for (int i = 1; i < worksheet.Dimension.Columns + 1; i++)
                    {
                        worksheet.Column(i).Width += 3;
                    }

                }
                #endregion



                #region Write Workbook to file
                pck.Save();
                Console.WriteLine($"{DateTime.Now.ToString().PadRight(30)} :: Report Generation Complete");

                dsT0OnboardingData.Tables.Clear();
                dsT0OnboardingData.Clear();

                #endregion

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An Error has occurred - terminating");
                Console.WriteLine(ex.Data);
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.Source);
                Console.WriteLine(ex.InnerException);
            }

            return 1;
        }

        static public string ReadApplicationSettings(string AppKey)
        {
            return ConfigurationManager.AppSettings[AppKey].ToString();
        }

        static public int ColumnToPosition(char colName)
        {
            return (int)colName % 32;
        }

        public static string PositionToColumn(int colPosition)
        {
            string result = string.Empty;
            while (--colPosition >= 0)
            {
                result = (char)('A' + colPosition % 26) + result;
                colPosition /= 26;
            }
            return result;
        }
    }
}
