param(
[parameter(mandatory=$true)][string]$vaultLoginID,
[parameter](mandatory=$true)][Security.SecureString]$AdminPassword

)



Import-Module -Name D:\Scripts\PACLI\AuthReport\Modules\PoShPACLI -Verbose
Import-Module -Name D:\Scripts\PACLI\AuthReport\Modules\PowerShellLogging -Verbose

Initialize-PoShPACLI -pacliFolder D:\Cyber_Ark\Pacli -Verbose

$daytime=Get-Date
$dt=$daytime,ToString('MM-dd-yyyy_hh-mm')
$LogFileName="D:\PACLI\AuthReport\LogFiles\AuthReport_$dt.log"
if($ImportErr)
{
write-host $ImportErr[0] -ForegroundColor Red
}
elseif(!$ImportErr) {
$logfile = Enable-LogFile -Path $LogFileName
$userList=Import-CSV D:\PACLI\AuthReport\Input\UsersList.csv -ErrorVariable ImportCSVErr -ErrorAction SilentyContinue
if($ImportErr)
{
write-host $ImportErr[1] -ForegroundColor Red
}
else
{

Start-PVPacli -verbose
$vault= "Prod Vault"
$vaultAddress=""
New-PVVaultDefination -vault $vault -address $vaultAddress -ErrorVariable vaultDefError -ErrorAction SilentyContinue -verbose
if($vaultDefError="CASVM005W Vault (Prod Vault) already exists in the Vaults Manager")
{
	write-host "Prod Vault already exists" -ForegroundColor Green
}


Connect-PVVault -vault $vault -user $vaultLoginID -password $AdminPassword  -verbose -ErrorVariable loginErr -ErrorAction SilentyContinue

if($loginErr)
{
	write-host $loginErr -ForegroundColor Red

	Stop-PVPacli -Verbose
}
elseif(!$loginErr)
{

for($i=0 ;$i -lt $userList.count;$i++){
$user=Get-PVUser -vault $vault -user $vaultLoginID -destUser $userList.User[$i] -ErrorVariable getAuthErr -ErrorAction SilentyContinue



if($getAuthErr)
{
	write-host $getAuthErr -ForegroundColor Red
}
else
{
	$Authtype=""
	
write-host $Authtype
if($user.RadiusAuth -eg "YES")
{
$Authtype="RADIUS"

}
elseif($user.RadiusAuth -eg "NO" -and $user.LDAPUser -eg "NO" -and $user.PassAuth -eg "YES")
{
	$Authtype="CyberARK"

}
elseif($user.RadiusAuth -eg "NO" -and $user.LDAPUser -eg "NO" -and $user.PassAuth -eg "NO" -and $user.LDAPUser -eg "YES")
{
	$Authtype="LDAP"
	
}
write-host $i $userList.User[$i] $Authtype -ForegroundColor Green
$results = @()
$details = @{
			User	= $userList.User[$i]
			AuthType=$Authtype
			
			
			
			
			
}

$results += New-Object PSObject -Property $details

		$results |select-object User,AuthType | export-csv -Path "":\scripts\PACLI\AuthReport\Output\User Authentication Details.csv" -NoTypeInformation -Append
}
}

Stop-PVPacli -Verbose
}

}
}
	