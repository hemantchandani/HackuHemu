
#Clear-Content Results_SafeReport.csv

#accepts the raw data from the json object and makes it readable to powershell
$rawdata = get-Content ./input/SafeDescription.json } ConvertFrom-Json

#removes most recent content in output folder so that only newest file is there
Remove-Item ./output/* -exclude old

#created a database to store variable in
$table = New-Object System.Data.DataTable
$table.Columns.Add("SafeName", "System.String") | Out-Null
$table.Columns.Add("Description", "System.String") | Out-Null


#loops through each item in the JSON object, grabs the safeame and description and appends it to the CSV
ForEach($d in $rawdata.GetSafesResult) {
	$description = $d.Description
	$name = $d.SafeName
	
	#created a row with entries for name and Description
	$newRow = $table.NewRow()
	$newRow.SafeName = $name
	$newRow.Description = $description
	$table.Rows.Add($newRow)
}
#exports data to the csv
echo Report generating...
$table | Export-csv ./output/SafeDescriptionReport_$(get-date -f MMDDYYYY).csv -NoTypeInformation
echo Report Created.

#Copies the Result_safe and SafeDescription.json report and output it to an archive folder with a time stamp
Copy-Item ./input/SafeDescription.json -Description "./input/backupSafeDescription$(get-date -f MMDDYYYY).json"
Remove-Item -path "./input/SafeDescription.json"

#archive the SafeDescription report
Copy-Item ./output/SafeDescriptionReport_$(get-date -f MMDDYYYY).csv -Destination "./output/old/SafeDescriptionReport_$(get-date -f MMDDYYYY).csv"

